package org.example;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oracle.bmc.ailanguage.AIServiceLanguageClient;
import com.oracle.bmc.ailanguage.model.*;
import com.oracle.bmc.ailanguage.requests.*;
import com.oracle.bmc.ailanguage.responses.*;
import com.oracle.bmc.auth.ConfigFileAuthenticationDetailsProvider;


import java.io.IOException;
import java.util.ArrayList;


public class AIServiceLanguageExample {


    private static AIServiceLanguageClient client;
    /*
        Please update value for profile, same as whatever you gave in config file
    * */
    private static final String CLIENT_ENDPOINT = "https://language.aiservice.me-abudhabi-2.oci.oraclecloud29.com";

    public AIServiceLanguageExample() throws IOException {
        /*
        Please update value for profile, same as whatever you gave in config file
        * */
        ConfigFileAuthenticationDetailsProvider provider =
                new ConfigFileAuthenticationDetailsProvider("~/.oci/config", "DEFAULT");

        client = AIServiceLanguageClient.builder().build(provider);
        client.setEndpoint(CLIENT_ENDPOINT);

    }

    public static void main(String[] args) throws IOException {

        AIServiceLanguageExample aiServiceLanguageExample=new AIServiceLanguageExample();

        /*
        Please update values for compartmentId, source and target language code
        * */
        String compartmentId = "ocid1.tenancy.oc29..aaaaaaaahiayxq7zyvb6vwsrzotdcso6zufs37m2myombuwb6izeksmqn4aq";
        String source="en";
        String target="es";
        // english to spanish
        translate(compartmentId,source,target);

        client.close();


    }

    public static void translate(String compartmentId, String source, String target) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();

        String englishText = "PLDT is the largest telecommunications company in the Philippines, offering a wide range of fixed and wireless voice, data, internet, and entertainment services to consumers and businesses over its extensive fiber optic backbone. The carrier’s international arm, PLDT Global Enterprise, provides business customers with operations across Asia Pacific, Europe, and the Americas with telecom, cloud, data center, and other services. Since PLDT Home deployed Oracle Digital Assistant in May 2020, 20% of its customer interactions across all its digital channels have transitioned to the chatbot, leading to more efficient and timely handling. The chatbot regularly handles order and reconnection requests, allows customers to pay their bills, checks for new products and services, and logs repair requests. With Oracle Digital Assistant, PLDT is now able to respond to customer queries in real time.";

        ArrayList<TextDocument> documents = new ArrayList<>();
        documents.add(TextDocument.builder().key("1")
                .text(englishText)
                .languageCode(source)
                .build());
        documents.add(TextDocument.builder().key("2")
                .text(englishText)
                .languageCode(source)
                .build());

        BatchLanguageTranslationDetails batchLanguageTranslationDetails = BatchLanguageTranslationDetails.builder()
                .compartmentId(compartmentId)
                .targetLanguageCode(target)
                .documents(documents).build();

        BatchLanguageTranslationRequest batchLanguageTranslationRequest = BatchLanguageTranslationRequest.builder()
                .batchLanguageTranslationDetails(batchLanguageTranslationDetails)
                .build();

        BatchLanguageTranslationResponse response = client.batchLanguageTranslation(batchLanguageTranslationRequest);

        String translatedText = objectMapper.writeValueAsString(response.getBatchLanguageTranslationResult());
        System.out.println(translatedText);
    }
    
}